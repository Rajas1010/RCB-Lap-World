-- MySQL dump 10.16  Distrib 10.1.48-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.1.48-MariaDB-0+deb9u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `details`
--

DROP TABLE IF EXISTS `details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `details` (
  `id` tinyint(4) DEFAULT NULL,
  `Name` varchar(39) DEFAULT NULL,
  `Processor` varchar(8) DEFAULT NULL,
  `Generation` varchar(8) DEFAULT NULL,
  `SSD` varchar(3) DEFAULT NULL,
  `SSD CAPACITY` varchar(6) DEFAULT NULL,
  `RAM` varchar(5) DEFAULT NULL,
  `CLOCK SPEED` varchar(7) DEFAULT NULL,
  `CACHE` tinyint(4) DEFAULT NULL,
  `CORES` tinyint(4) DEFAULT NULL,
  `OS_ARCH` varchar(6) DEFAULT NULL,
  `SCREEN_SIZE` varchar(9) DEFAULT NULL,
  `WIRELESS` varchar(7) DEFAULT NULL,
  `SLOT` varchar(15) DEFAULT NULL,
  `WEIGHT` varchar(7) DEFAULT NULL,
  `WARRANTY` varchar(7) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `details`
--

LOCK TABLES `details` WRITE;
/*!40000 ALTER TABLE `details` DISABLE KEYS */;
INSERT INTO `details` VALUES (1,'dell vostro 3500','INTEL I3','11th GEN','YES','512 GB','8 GB','1.7 Ghz',8,4,'64 Bit','15.6 inch','Realtek','1x HDMI','1.69KG','2 YEARS'),(2,'lenovo ideapad 3','INTEL I7','10th GEN','YES','512 GB','16 GB','2.4 Ghz',8,4,'64 Bit','16.4 inch','Realtek','1x HDMI','1.5 KG','3 YEARS'),(3,'lenovo ideapad 3 celeron duel core','INTEL I3','4th GEN','YES','256 GB','4 GB','1.7 Ghz',8,2,'64 Bit','15.6 inch','Realtek','1x HDMI ,2x USB','1.69 KG','2 YEARS'),(4,'asus pentinum quad core','INTEL I3','11th GEN','YES','64GB','4 GB','1.7 Ghz',8,4,'64 Bit','15.6 inch','Realtek','1x HDMI','1.69KG','2 YEARS'),(5,'dell inspiron core 15','INTEL I3','11th GEN','YES','64GB','16GB','1.7 Ghz',8,4,'32 Bit','15.6 inch','Realtek','1x HDMI','1.69KG','3 YEARS'),(6,'acer nitro 5 ryzen 5 hex core 4600h','INTEL I3','11th GEN','YES','64GB','8GB','1.7 Ghz',8,4,'32 Bit','15.6 inch','Realtek','1x HDMI','1.69KG','2 YEARS'),(7,'acer aspire 7 core 15','INTEL I3','10th GEN','YES','64GB','8GB','1.7 Ghz',4,2,'64 Bit','14.6 inch','Realtek','1x HDMI','1.80KG','5 YEARS'),(8,'lenovo legionv 5ryzen 5 hexa core 4600h','INTEL I5','10th GEN','YES','64GB','4GB','1.7 Ghz',4,2,'32 Bit','16.4 inch','Realtek','1x HDMI','1.60KG','2 YEARS'),(9,'ASUS RYZEN 3 DUEL CORE 3250U ','INTEL I5','3th GEN','YES','64GB','8GB','1.7 Ghz',6,4,'32 Bit','16.4 inch','Realtek','1x HDMI','1.85KG','2 YEARS'),(10,'APPLE 2020 MACBOOK AIR M1 ','INTEL I5','10th GEN','YES','512GB','16GB','1.7 Ghz',6,4,'32 Bit','15.6 inch','Realtek','1x HDMI','1.90KG','2 YEARS'),(11,'NOKIA PUREBOOK S14 CORE ','INTEL I5','10th GEN','YES','512GB','16GB','1.7 Ghz',6,4,'64 Bit','15.6 inch','Realtek','1x HDMI','1.92KG','3 YEARS'),(12,'ASUS EEEBOOK 12 CELERON DUEL CORE ','INTEL I5','10th GEN','YES','512GB','4GB','1.7 Ghz',8,4,'32 Bit','15.6 inch','Realtek','1x HDMI','1.87KG','3 YEARS'),(13,'LENOVO IDEAPAD 3 CORE 13 ','INTEL I5','10th GEN','YES','512GB','8GB','1.7 Ghz',8,4,'32 Bit','14.6 inch','Realtek','1x HDMI','1.87KG','3 YEARS'),(14,'HP CORE 13 ','INTEL I5','11th GEN','YES','512GB','8GB','1.7 Ghz',8,4,'64 Bit','15.6 inch','Realtek','1x HDMI','1.87KG','2 YEARS'),(15,'HP RYZEN 3 DUAL CORE 3250U ','INTEL I5','11th GEN','YES','512GB','8GB','1.7 Ghz',6,4,'64 Bit','15.6 inch','Realtek','1x HDMI','1.87KG','2 YEARS'),(16,'MSI GF65 THIN HEXA CORE 15 ','INTEL I5','10th GEN','YES','512GB','8GB','1.7 Ghz',6,2,'32 Bit','15.6 inch','Realtek','1x HDMI','1.84KG','2 YEARS'),(17,'ASUS VIVOBOOK 15 CORE ','INTEL I3','10th GEN','YES','512GB','4GB','1.7 Ghz',6,4,'64 Bit','14.6 inch','Realtek','1x HDMI','1.84KG','2 YEARS'),(18,'HP RYZEN 3 DUEL CORE 3250U','INTEL I3','10th GEN','YES','512GB','8GB','1.7 Ghz',6,4,'64 Bit','14.6 inch','Realtek','1x HDMI','1.86KG','2 YEARS'),(19,'MSI GF65 THIN HEXA CORE ','INTEL I5','10th GEN','YES','512GB','16GB','1.7 Ghz',6,4,'64 Bit','14.6 inch','Realtek','1x HDMI','1.86KG','2 YEARS'),(20,'ACER ASPIRE 3 DUEL CORE 3020E ','INTEL I5','10th GEN','YES','512GB','4GB','1.7 Ghz',8,4,'64 Bit','14.6 inch','Realtek','1x HDMI','1.86KG','2 YEARS'),(21,'DELL INSPIRON AHLON DUEL CORE 3050U ','INTEL I5','10th GEN','YES','512GB','8GB','1.7 Ghz',8,4,'64 Bit','15.6 inch','Realtek','1x HDMI','2.12KG','3 YEARS'),(22,'INFINIX INBOOK X1 CORE ','INTEL I3','10th GEN','YES','512GB','8GB','1.7 Ghz',8,4,'32 Bit','16.4 inch','Realtek','1x HDMI','1.95KG','3 YEARS'),(23,'HP PAVILLON RYZEN 5 HEXA CORE 5600H ','INTEL I3','10th GEN','YES','512GB','4GB','1.7 Ghz',8,4,'32 Bit','16.4 inch','Realtek','1x HDMI','1.95KG','3 YEARS'),(24,'MSI GF65 THIN CORE  ','INTEL I7','10th GEN','YES','512GB','16GB','1.7 Ghz',8,4,'32 Bit','16.4 inch','Realtek','1x HDMI','2.10KG','5 YEARS');
/*!40000 ALTER TABLE `details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laptop`
--

DROP TABLE IF EXISTS `laptop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laptop` (
  `id` tinyint(4) DEFAULT NULL,
  `Lname` varchar(42) DEFAULT NULL,
  `detail` varchar(39) DEFAULT NULL,
  `RAM` varchar(5) DEFAULT NULL,
  `Price` mediumint(9) DEFAULT NULL,
  `Avaliable` tinyint(4) DEFAULT NULL,
  `Image` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laptop`
--

LOCK TABLES `laptop` WRITE;
/*!40000 ALTER TABLE `laptop` DISABLE KEYS */;
INSERT INTO `laptop` VALUES (1,'Dell 3400 Vostro 14 Laptop','11th Gen Intel Core i5-1115G/256 GB SSD','8 GB',67000,7,'C:/Users/rasu/Pictures/Icon128/iconDell01.png'),(2,'Lenovo IdeaPad 3','11th Gen Intel Core i7-1115G/512 GB SSD','16 GB',68998,8,'C:/Users/rasu/Pictures/Icon128/iconDell02.png'),(3,'Lenovo IdeaPad 3 CELERON DUAL CORE 4TH GEN',' WINDOWS 11 HOME-1115G/512 GB SSD','16 GB',76000,7,'C:/Users/rasu/Pictures/Icon128/iconDell02.png'),(4,'ASUS PENTIUM QUAD CORE',' 64GB EMMC STORAGE','4 GB',78000,7,'C:/Users/rasu/Pictures/Icon128/iconDell01.png'),(5,'DELL INSPIRON CORE I5 11TH GEN','WINDOWS 11 HOME','16GB',83000,9,'C:/Users/rasu/Pictures/Icon128/iconDell01.png'),(6,'ACER NITRO 5 RYZEN 5 HEX CORE 4600H','NVIDIA GEFORCE GTX 1650','8GB',75745,9,'C:/Users/rasu/Pictures/Icon128/iconDell02.png'),(7,'ACER ASPIRE 7 CORE I5 10TH GEN','NVIDIA GEFORCE GTX 1650','8GB',66459,7,'C:/Users/rasu/Pictures/Icon128/iconDell02.png'),(8,'LENOVO LEGIONV 5 RYZEN 5 HEXA CORE 4600H','WINDOWS 10 HOME','4GB',45879,4,'C:/Users/rasu/Pictures/Icon128/iconDell01.png'),(9,'ASUS RYZEN 3 DUAL CORE 3250U 3RD GEN','WINDOWS 10 HOME','8GB',68743,6,'C:/Users/rasu/Pictures/Icon128/iconDell01.png'),(10,'APPLE 2020 MACBOOK AIR M1','MAC OS BIG SUR','16GB',142569,10,'C:/Users/rasu/Pictures/Icon128/iconDell02.png'),(11,'NOKIA PUREBOOK S14 CORE I5 10TH GEN','NVIDIA GEFORCE RTX 3060','16GB',81499,14,'C:/Users/rasu/Pictures/Icon128/iconDell02.png'),(12,'ASUS EEEBOOK 12 CELERON DUAL CORE',' EMMC STORAGE','4GB',42563,10,'C:/Users/rasu/Pictures/Icon128/iconDell01.png'),(13,'LENOVO IDEAPAD 3 CORE I3 10TH GEN',' WINDOWS 11 HOME 256GB SSD','8GB',53435,6,'C:/Users/rasu/Pictures/Icon128/iconDell02.png'),(14,'HP CORE I3 11TH GEN',' WINDOWS 11 HOME','8GB',67245,6,'C:/Users/rasu/Pictures/Icon128/iconDell02.png'),(15,'HP RYZEN 3 DUAL CORE 3250U','WINDOWS 10 HOME','8GB',62389,8,'C:/Users/rasu/Pictures/Icon128/iconDell01.png'),(16,'MSI GF65 THIN HEXA CORE I5 10TH GEN','NVIDIA geForce RTX 3060','6GB',70514,10,'C:/Users/rasu/Pictures/Icon128/iconDell01.png'),(17,'ASUS VIVOBOOK 15 CORE I3 10TH GEN','WINDOWS 11 HOME','4GB',59415,7,'C:/Users/rasu/Pictures/Icon128/iconDell02.png'),(18,'HP RYZEN 3 DUAL CORE 3250U','WINDOWS 10 HOME','8GB',68415,9,'C:/Users/rasu/Pictures/Icon128/iconDell02.png'),(19,'MSI GF65 THIN HEXA CORE I5 10TH GEN','NVIDIA GEFORCE RTX 3060','16GB',79349,9,'C:/Users/rasu/Pictures/Icon128/iconDell01.png'),(20,'ACER ASPIRE 3 DUAL CORE 3020E','WINDOWS 11 HOME','4GB',43215,13,'C:/Users/rasu/Pictures/Icon128/iconDell01.png'),(21,'DELL INSPIRON ATHLON DUAL CORE 3050U','WINDOWS 11 HOME','8GB',98752,10,'C:/Users/rasu/Pictures/Icon128/iconDell01.png'),(22,'INFINIX INBOOK X1 CORE I3 10TH GEN','WINDOWS 11 HOME','8GB',79582,7,'C:/Users/rasu/Pictures/Icon128/iconDell02.png'),(23,'HP PAVILLION RYZEN 5 HEXA CORE 5600H','NVIDIA GEFORCE GTX 1650','4GB',68529,8,'C:/Users/rasu/Pictures/Icon128/iconDell01.png'),(24,'MSI GF65 THIN CORE I7 10TH GEN','NVIDIA GEFORCE RTX 3060','16GB',70453,6,'C:/Users/rasu/Pictures/Icon128/iconDell01.png'),(25,'lenovo','i7,11th gen','8gb',87000,8,'C:Users\rasuPicturesIcon128iconDell01.png'),(26,'Apple macBook 8','i7,10th gen','16gb',99999,8,'C:Users\rasuPicturesIcon128iconDell01.png'),(27,'hp pavlion','intel core i9','16 gb',70000,2,'C:Users\rasuPicturesIcon128iconDell01.png'),(28,'rog tuff','ryzen','16 gb',120000,8,'C:Users\rasuPicturesIcon128\rog tuff.png'),(29,'Apple macBook 12','i7','16gb',100000,8,'C:Users\rasuPicturesIcon128icon01.png');
/*!40000 ALTER TABLE `laptop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqlite_sequence`
--

DROP TABLE IF EXISTS `sqlite_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqlite_sequence` (
  `name` varchar(7) DEFAULT NULL,
  `seq` mediumint(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqlite_sequence`
--

LOCK TABLES `sqlite_sequence` WRITE;
/*!40000 ALTER TABLE `sqlite_sequence` DISABLE KEYS */;
INSERT INTO `sqlite_sequence` VALUES ('details',24),('laptop',864597);
/*!40000 ALTER TABLE `sqlite_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `username` varchar(4) DEFAULT NULL,
  `password` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('raja','se12@'),('r','r');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-18 10:46:25
